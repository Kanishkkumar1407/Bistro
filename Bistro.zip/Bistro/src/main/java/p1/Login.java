package p1;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String uname = request.getParameter("username");
        String pn = request.getParameter("phoneNumber");
        try {
            // Database connection details
            String url = "jdbc:mysql://localhost:3306/foodie";
            String username = "root";
            String password = "tiger";
            Class.forName("com.mysql.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(url, username, password)) {
                // Insert data into the users table
                String insertSql = "insert into users (username, phonenumber) VALUES (?, ?)";
                try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                    insertStmt.setString(1, uname);
                    insertStmt.setString(2, pn);
                    insertStmt.executeUpdate();
                }
                String selectSql = "SELECT * FROM users WHERE username = ? AND phonenumber = ?";
                try (PreparedStatement pstmt = conn.prepareStatement(selectSql)) {
                    pstmt.setString(1, uname);
                    pstmt.setString(2, pn);
                    try (ResultSet rs = pstmt.executeQuery()) {
                        if (rs.next()) {
                            // User found, redirect to another page
                            response.sendRedirect("Home.jsp");
                        }
                    }
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.getWriter().println("Database connection error: " + e.getMessage());
        }
    }
}