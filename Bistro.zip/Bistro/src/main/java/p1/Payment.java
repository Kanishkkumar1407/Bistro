package p1;

import java.io.Serializable;
public class Payment implements Serializable {
	    private int id;
	    private String method;

	    public int getId() {
	        return id;
	    }

	    public void setId(int id) {
	        this.id = id;
	    }

	    public String getMethod() {
	        return method;
	    }

	    public void setMethod(String method) {
	        this.method = method;
	    }
}
